var httpUtils = require('httpUtils');
var Utility = {
    clamp01 : function (value) {
        if(value < 0){
            return 0;
        }

        if(value > 1){
            return 1;
        }
        return value;
    },

    clamp : function (value, min, max) {
        if (value < min)
        {
            value = min;
        }
        else
        {
            if (value > max)
            {
                value = max;
            }
        }
        return value;
    },

    repeat : function(t, length){
        return t - Math.floor(t / length) * length
    },

    lerp : function(from, to, t){
        t = this.clamp01 (t);
        return cc.v2(from.Position.x + (to.Position.x - from.Position.x) * t, from.Position.y + (to.Position.y - from.Position.y) * t);
        //return cc.v2(from.x + (to.x - from.x) * t, from.y + (to.y - from.y) * t);
    },
    lerpPos : function(from, to, t){
        t = this.clamp01 (t);
        return cc.v2(from.x + (to.x - from.x) * t, from.y + (to.y - from.y) * t);
        //return cc.v2(from.x + (to.x - from.x) * t, from.y + (to.y - from.y) * t);
    },
    lerpAngle : function(a,b,t){
        let num = this.repeat(b - a, 360);
        if (num > 180)
        {
            num -= 360;
        }
        return a + num * this.clamp01(t);
    },

    Deg2Rad:function (angle) {
        return angle * (Math.PI / 180);
    },
    
    Rad2Deg:function (angle) {
        return angle * (180 / Math.PI);
    },
    VecAdd:function(vec1, vec2)
    {
        let vec = new cc.Vec2(vec1.x + vec2.x, vec1.y + vec2.y);
        return vec;
    },
    VecSub:function(vec1,vec2)
    {
        let vec = new cc.Vec2(vec1.x - vec2.x, vec1.y - vec2.y);
        return vec;
    },
    ConvertNumber2String:function(number){
        let result = "";
        var part;
        if(number >= 100000000){
            if(number % 100000000 === 0){
                part = number / 100000000;
                result = part.toFixed(0) + '亿';
            }else{
                part = number / 100000000;
                result = part.toFixed(2) + '亿';
            }
        }else if(number >= 10000){
            if(number % 10000 === 0){
                part = number / 10000;
                result = part.toFixed(0) + '万';
            }else{
                part = number / 10000;
                result = part.toFixed(2) + '万';
            }
        }else{
            result = number;
        }
        return result;
    },

    ConvertTelephoneFare2String(count) {
        // let fare = count / 100;
        // fare = fare.toFixed(2);
        // return "{0}元".format(fare);
        return count;
    },
    ConvertPhoneFee2String(count) {
        let fare = count / 100;
        fare = Math.floor(fare);
        return fare;
    },

    ConvertIntDateTime(d) {
        let date = new Date(d);
        let time = date.toLocaleDateString() + " " + date.toTimeString().substr(0, 8);
        return time;
    },
    GetIOSChannelName(){
        let IOSChanelName = (cc.sys.localStorage.getItem("IOSChanelName"));
        console.log("IOSChanelName = ",IOSChanelName);
        if (GameConfig.ChannelName == GLOBAL.ENUM_SDK_CHANNEL.IOS){
            if (IOSChanelName){
                return JSON.parse(IOSChanelName);
            } else {
                return GameConfig.ChannelName;
            }
        }else {
            return GameConfig.ChannelName;
        }
    },

    get NowTimeStamp(){
        return this.ConvertIntDateTime((new Date()).valueOf());
    },

    EncryptImageAuthenCode(phone, code, timeStamp) {
        //tiemStamp = new Date().getTime();
        let stringAuth = phone + GameConfig.AppSecret + code + timeStamp;
        return md5Cache.hex_md5(stringAuth);
    },

    SpliteList(data, count) {
        let clone = data;
		if(data == null && data.length < count) {
			return null;
		}
		let result = [];
		while(clone.length != 0) {
            let reallyCount = count > clone.length ? clone.length : count;
            let cache = clone.slice(0, reallyCount);
			result.concat(cache);
			clone.splice(0, reallyCount);
		}
		return result;
    },

    // setNodeFrame:function(node, frameStr) {
    //     const paths = frameStr.split(':');
    //     cc.loader.loadRes(paths[0], cc.SpriteAtlas, (err, atlas) => {
    //         if (err) {
    //             console.warn(err);
    //         } else {
    //             const frame = atlas.getSpriteFrame(paths[1]);
    //             if (cc.isValid(node)) {
    //                 node.getComponent(cc.Sprite).spriteFrame = frame;
    //             }
    //         }
    //     });
    // },
    HandlerError:function(json, input){
        return false;
    },

    // it returns a random value between min and max included
    RandomRange:function(min, max){
        const rnd = Math.floor(Math.random() * (max - min + 1) + min);
        return rnd;
    },

    Distance:function(pos1,pos2){
        const v1 = cc.v2(pos1.x, pos1.y);
        const v2 = cc.v2(pos2.x, pos2.y);
        const subV = v1.sub(v2);
        const distance = subV.mag(v2);
        return distance;
    },
    /*
    * // 通用添加小喇叭 // Add by zhanghow at 2019.3.13
    * param json:服务端推的数据  parsentNode:所添加的父节点
    * 注意：父节点需在当前场景建立，注意添加widget来适配
    * */

    addLoudSpeaker:function(json,parsentNode){
        // 加载 Prefab
        let node = parsentNode.getChildByName('LoudSpeaker');
        if(node == null) {
            node = cc.instantiate(cc.loader.getRes(prefabFactory.LoudSpeaker));
            if(parsentNode != null && cc.isValid(parsentNode)) {
                node.parent = parsentNode;
            }
        } else {
            node.active = true;
        }
        
        if(node != null && json!=null){
            let spt = node.getComponent('LoudSpeaker');// 添加至待播放队列
            spt.PushMessage(json.message);
        }

    },
    addCrazyLoading:function(json,parsentNode){
        // 加载 Prefab
        let node = parsentNode.getChildByName('CrazyLoading');
        if(node == null) {
            prefabFactory.instantiatePrefab(prefabFactory.CrazyLoading, parsentNode, null);
        } else {
            node.active = true;
        }

        if(node != null && json!=null){
            let spt = node.getComponent('CrazyLoading');
            // this.node.removeChild("CrazyLoading");
        }

    },

    CheckNetWorkReachability() {

        return true;


        let isOK = false;


        if(cc.sys.isNative) {
            if(cc.sys.os === cc.sys.OS_ANDROID) {
                //console.log("平台：",cc.sys.os);

                isOK = jsb.reflection.callStaticMethod("org/cocos2dx/javascript/AppActivity", "isNetworkConnected", "()Z");
                //console.log("android返回网络状态信息：", isOK);
                return isOK;
            }
            if(cc.sys.os === cc.sys.OS_IOS) {
                //console.log("平台", "cc.sys.OS_IOS");
                isOK = jsb.reflection.callStaticMethod('AppController', "checkNetConnect");
                //console.log("ios返回网络状态信息：", isOK);
                return isOK;
            }
        } else if(cc.sys.isBrowser) {
            isOK = true;
        }

        if(!isOK) {
            MessageBox.show("当前网络状态不可用，请确认网络状态", MessageBox.OK, null);
        }
        
        return isOK;
    },

    GetFragmentConfig(callBack) {
        httpUtils.getInstance().httpGets(GameConfig.GetFragmentConfigURL, (data) => {
            if(data.error) {
                if(callBack != null) {
                    callBack(null);
                };
                return;
            }

            if(GLOBAL.isStringNullOrEmpty(data)) {
                return;
            }

            let config = JSON.parse(data);
            if(callBack != null) {
                callBack(config);
            }
        })
    },

    /*
    * // 获取当前时间 // Add by zhanghow at 2019.3.20
    * 格式 2019-3-20 14:20:10
    * */
    getNowTime:function(){
        let myDate = new Date();
        // myDate.getYear();        //获取当前年份(2位)
        let y = myDate.getFullYear();    //获取完整的年份(4位,1970-????)
        let m = myDate.getMonth();       //获取当前月份(0-11,0代表1月)
        let d = myDate.getDate();        //获取当前日(1-31)
        // myDate.getDay();         //获取当前星期X(0-6,0代表星期天)
        // myDate.getTime();        //获取当前时间(从1970.1.1开始的毫秒数)
        let h = myDate.getHours();       //获取当前小时数(0-23)
        let min = myDate.getMinutes();     //获取当前分钟数(0-59)
        let s = myDate.getSeconds();     //获取当前秒数(0-59)
        // myDate.getMilliseconds();    //获取当前毫秒数(0-999)
        // myDate.toLocaleDateString();     //获取当前日期
        // let mytime = myDate.toLocaleTimeString();     //获取当前时间
        if (h<10){
            h = '0'+h;
        }
        if (min<10){
            min = '0'+min;
        }
        if (s<10){
            s = '0'+s;
        }
        return y + '-' + (m+1) + '-' + d + ' ' + h + ':' + min + ':' + s;
    },
    getDateTimeString:function(timeStamp = null)
    {
        let myDate;
        if(timeStamp){
            myDate = new Date(timeStamp);
        }else{
            myDate = new Date();
        }
        // myDate.getYear();        //获取当前年份(2位)
        let y = myDate.getFullYear();    //获取完整的年份(4位,1970-????)
        let m = myDate.getMonth();       //获取当前月份(0-11,0代表1月)
        let d = myDate.getDate();        //获取当前日(1-31)
        // myDate.getDay();         //获取当前星期X(0-6,0代表星期天)
        // myDate.getTime();        //获取当前时间(从1970.1.1开始的毫秒数)
        let h = myDate.getHours();       //获取当前小时数(0-23)
        let min = myDate.getMinutes();     //获取当前分钟数(0-59)
        let s = myDate.getSeconds();     //获取当前秒数(0-59)
        // myDate.getMilliseconds();    //获取当前毫秒数(0-999)
        // myDate.toLocaleDateString();     //获取当前日期
        // let mytime = myDate.toLocaleTimeString();     //获取当前时间
        if (h<10){
            h = '0'+h;
        }
        if (min<10){
            min = '0'+min;
        }
        if (s<10){
            s = '0'+s;
        }
        return y + '-' + (m+1) + '-' + d + ' ' + h + ':' + min + ':' + s;
    },
    getDateTimeMMDDHHmm:function(myDate){
        // myDate.getYear();        //获取当前年份(2位)
        //let y = myDate.getFullYear();    //获取完整的年份(4位,1970-????)
        let m = myDate.getMonth() + 1;       //获取当前月份(0-11,0代表1月)
        let d = myDate.getDate();        //获取当前日(1-31)
        // myDate.getDay();         //获取当前星期X(0-6,0代表星期天)
        // myDate.getTime();        //获取当前时间(从1970.1.1开始的毫秒数)
        let h = myDate.getHours();       //获取当前小时数(0-23)
        let min = myDate.getMinutes();     //获取当前分钟数(0-59)
        //let s = myDate.getSeconds();     //获取当前秒数(0-59)
        // myDate.getMilliseconds();    //获取当前毫秒数(0-999)
        // myDate.toLocaleDateString();     //获取当前日期
        // let mytime = myDate.toLocaleTimeString();     //获取当前时间
        if (m<10){
            m = '0'+m;
        }

        if (d<10){
            d = '0'+d;
        }

        if (h<10){
            h = '0'+h;
        }
        if (min<10){
            min = '0'+min;
        }
        
        return m + '-' + d + ' ' + h + ':' + min;
    },
    getDateTimeHHMM(timeStamp)
    {
        let myDate = new Date(timeStamp);
        
        let h = myDate.getHours();       //获取当前小时数(0-23)
        let min = myDate.getMinutes();     //获取当前分钟数(0-59)
        
        

        if (h<10){
            h = '0'+h;
        }
        if (min<10){
            min = '0'+min;
        }
        
        return h + ':' + min;
    },
    // 得到时间戳 // ms 级别
    getTimeStamp(){
        var timestamp = (new Date()).getTime();
        return timestamp;
    },

    Shuffle:function(cards){
        for(let i=0; i<cards.length; i++){
            let temp = cards[i];
            const randomIndex = this.RandomRange(0, cards.length-1);
            cards[i] = cards[randomIndex];
            cards[randomIndex] = temp;
        }
    },

    GetFragmentSmallImageURL(id) {
        if(GLOBAL.FragmentConfig == null ||
            GLOBAL.FragmentConfig.compose == null) 
        {
            return null;
        }

        let len = GLOBAL.FragmentConfig.compose.length;
        for(let i = 0; i < len; i++) {
            let item = GLOBAL.FragmentConfig.compose[i];
            if(item.id == id) {
                return item.smallUrl;
            }
        }

        return null;
    },
    FishSetTimeout(obj,callBack,time){
        return setTimeout(()=>{
            if(!obj || !cc.isValid(obj)){
                console.warn("FishSetTimeout obj=",obj);
                return;
            }
            try{
                callBack();
            }catch(e){
                console.warn("FishSetTimeout failed:",e);
            }
        },time);
    },
    FishSetInterval(obj,callBack,time){
        var timer=setInterval(()=>{
            if(!obj || !cc.isValid(obj)){
                console.warn("FishSetInterval obj=",obj,",timer=",timer);
                clearInterval(timer);
                return;
            }
            try{
                callBack();
            }catch(e){
                clearInterval(timer);
                console.warn("FishSetInterval failed:",e,",tiemr=",timer);
            }
        },time);
        return timer;
    },
    // JSON.Parse()参数为空的话 微信小程序会崩溃
    JSONParse(str){
        if (str != ""&&str != undefined){
            //console.log('str!=null',str);
            return JSON.parse(str);
        }else {
            return null;
        }
    },
    CutNumberOneByOne(container,number){
        for(let i=0;i<String(number).length;i++){
            let num=0;
            num=(number / Math.pow(10,i)) %10;
            num = Math.floor(num);
            container.push(num);
        }
        return container;
    },

    GetSingleRewardID(info){
        let itemInfo = {};
        if(info.gold!=0){
            itemInfo.id = GameConfig.GoldDropID;
            itemInfo.count = info.gold;
            return itemInfo;
        }
        if(info.jewel!=0){
            itemInfo.id = GameConfig.DiamondDropID;
            itemInfo.count = info.jewel;
            return itemInfo;
        }
        let item = null;
        info.items.forEach(elelment=>{
            if(elelment.count!=0){
                item = elelment;
            }
        });
        return item;
    },

    formatSeconds(value) {
        var secondTime = parseInt(value);// 秒
        var minuteTime = 0;// 分
        var hourTime = 0;// 小时
        if(secondTime > 60) {//如果秒数大于60，将秒数转换成整数
            //获取分钟，除以60取整数，得到整数分钟
            minuteTime = parseInt(secondTime / 60);
            //获取秒数，秒数取佘，得到整数秒数
            secondTime = parseInt(secondTime % 60);
            //如果分钟大于60，将分钟转换成小时
            if(minuteTime > 60) {
                //获取小时，获取分钟除以60，得到整数小时
                hourTime = parseInt(minuteTime / 60);
                //获取小时后取佘的分，获取分钟除以60取佘的分
                minuteTime = parseInt(minuteTime % 60);
            }
        }
        var secStr = secondTime >= 10 ? "" + secondTime : "0" + secondTime;
        var minStr = minuteTime >= 10 ? "" + minuteTime : "0" + minuteTime;
        var hourStr = hourTime >= 10 ? "" + hourTime : "0" + hourTime;
        var result = hourStr+":"+minStr+":"+secStr;
        return result;
    },
    formatSeconds2MinSec(value)
    {
        var secondTime = parseInt(value);// 秒
        var minuteTime = 0;// 分
        if(secondTime > 60) {//如果秒数大于60，将秒数转换成整数
            //获取分钟，除以60取整数，得到整数分钟
            minuteTime = parseInt(secondTime / 60);
            //获取秒数，秒数取佘，得到整数秒数
            secondTime = parseInt(secondTime % 60);
        }
        var secStr = secondTime >= 10 ? "" + secondTime : "0" + secondTime;
        var minStr = minuteTime >= 10 ? "" + minuteTime : "0" + minuteTime;
        var result = minStr+":"+secStr;
        return result;
    },
    formatSeconds2MinSec2(value)
    {
        var secondTime = parseInt(value);// 秒
        var minuteTime = 0;// 分
        if(secondTime > 60) {//如果秒数大于60，将秒数转换成整数
            //获取分钟，除以60取整数，得到整数分钟
            minuteTime = parseInt(secondTime / 60);
            //获取秒数，秒数取佘，得到整数秒数
            secondTime = parseInt(secondTime % 60);
        }
        var secStr = secondTime >= 10 ? "" + secondTime : "0" + secondTime;
        var minStr = minuteTime >= 10 ? "" + minuteTime : "0" + minuteTime;
        var result = minStr+"分"+secStr+"秒";
        return result;
    },
    
    

    

    GetIsAnyDoorWork(type)
    {
        if(GLOBAL.player != null
            && GLOBAL.player.superDoor != null
            && GLOBAL.player.superDoor.length > type)
            {
                return GLOBAL.player.superDoor[type] != 0;
            }
            return false;
    },

    GetOpenTime(openTime)
    {
        let result = "";
        openTime.forEach(item=>{
            let time = " {0}:{1}-{2}:{3}".format(item.start.hour,
                                                this.GetMinTimeString(item.start.min),
                                                item.end.hour,
                                                this.GetMinTimeString(item.end.min));
            result+=time;
        });
        return result;
    },
    GetMinTimeString(min)
    {
        if(min >= 10)
        {
            return min;
        }
        return "0{0}".format(min);
    },

    CheckInTime(startHour,startMin,endHour,endMin)
    {
        let curDate = new Date();
        let beginTime = new Date(curDate.getFullYear(),curDate.getMonth(),curDate.getDate(),
                                parseInt(startHour),parseInt(startMin),0);
        let endTime = new Date(curDate.getFullYear(),curDate.getMonth(),curDate.getDate(),
                                parseInt(endHour),parseInt(endMin),0);
        return (new Date().getTime() > beginTime.getTime() && new Date().getTime() < endTime.getTime());
    },
    GetRewardType(fishPrice)
    {
        if(Math.pow(10,6) <= fishPrice && fishPrice < Math.pow(10,7))
        {
            return 0;
        }else if(Math.pow(10,7) <= fishPrice)
        {
            return 1;
        }else{
            return -1;
        }
    },
    isLootEmpty(loot) {

        if (!!loot) {
    
            if (loot.hasOwnProperty("gold") && loot.gold > 0) {
    
                return false;
            }
    
            if (loot.hasOwnProperty("jewel") && loot.jewel > 0) {
    
                return false;
            }
    
            if (loot.hasOwnProperty("items") && Array.isArray(loot.items)) {
    
                if (loot.items.length === 0) {
    
                    return true;
                }
    
                var items = loot.items;
                var flag = items.some(function (item) {
    
                    if (item.hasOwnProperty("count")) {
    
                        return item.count > 0;
                    }
                    return false;
                });
    
                return !flag;
            }
        }
    
        return true;
    },
    //得到一个随机的SimId
    getSimId(randomFlag,min,max){
        let simid = cc.sys.localStorage.getItem("SimId");

        if (simid){
            return simid;
        }
        var str = " ";
        let range = min;
        let arr = ['0','1','2','3','4','5','6','7','8','9','a','b','c','d','e','f'];
        //随机产生
        if ( randomFlag ) {
            range = Math.round( Math.random( ) * ( max-min)) + min;
        }
        for ( var i=0; i<range;i++ )
        {
            let pos = Math.round(Math.random() * (arr.length - 1));
    　　　　      str += arr [pos];
            // console.log(str);
        }
        cc.sys.localStorage.setItem("SimId",(str));
        return str;
    },
};

module.exports = Utility;