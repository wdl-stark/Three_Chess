// Learn cc.Class:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] http://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] http://www.cocos2d-x.org/docs/creator/en/scripting/life-cycle-callbacks.html

var MessageBox = {};

(function () {
    // MessageBox.OK_CALCEL = 1;
    // MessageBox.OK = 2;
    MessageBox.RETURN_RECONNECT = 3;
    MessageBox.OKCancel = 0;
    MessageBox.OK = 1;
    MessageBox.DeleteOrGet = 2;
    // MessageBox.ReconnectOrReturn = 3;
    MessageBox.Update = 4;
    MessageBox.UpdateOrGoOnGame = 5;
    MessageBox.CancelOrImmediatelyPay = 6;
    MessageBox.AddictionOrCancel = 7;


    MessageBox.StyleEnum = cc.Enum(
	{
		OKCancel:0,
		OK:1,
		DeleteOrGet:2,
		ReconnectOrReturn:3,
		Update:4,
		UpdateOrGoOnGame:5,
		CancelOrImmediatelyPay:6,
		AddictionOrCancel:7,
    });
    
    MessageBox.ButtonStyle = cc.Enum({
        OK:0,
        CANCLE:1,
        RECONNECT:2,
        BACKLOGIN:3,
        GOUP:4,
        CONTINUE:5,
        GOSHOP:6,
        GOCHECK:7,
        DELAYGO:8,
    });

    MessageBox.show = function (message, type, callBack) {
        MessageBox.clear();// 先清除其他弹窗
        const instance = cc.instantiate(window.MessageBoxPref);
        instance.parent = cc.find('Canvas');
        instance.zIndex = cc.macro.MAX_ZINDEX;
        let messageDialog = instance.getComponent('MessageDialog');
        messageDialog.show(message, type, callBack);
        // cc.loader.loadRes('MessageBox', cc.Prefab, function(error, prefab){
        //     if(error){
        //         cc.log(error);
        //         return;
        //     }
        //     cc.log("prefab load completed");
        //     let instance = cc.instantiate(prefab);
        //     instance.parent = cc.find('Canvas');
        //     let messageDialog = instance.getComponent('MessageDialog');
        //     messageDialog.show(message, type, callBack);
        // });

    };
    MessageBox.clear = function () {
        // GLOBAL.HasPay = false;
        let parent = cc.find('Canvas');
        let childrenArr = parent.children;
        let length = childrenArr.length;
        for(let i = length-1; i >= 0; i--) {
            if (childrenArr[i]){
                if(childrenArr[i].name == "MessageBox"
                    ||childrenArr[i].name=="CommonMessageText"
                    ||childrenArr[i].name == "Shop"
                    ||childrenArr[i].name=="VIPQuickPay"
                    ||childrenArr[i].name=="SuperLuckydrawRecharge"
                    ||childrenArr[i].name=="DailyRecharge"
                    ||childrenArr[i].name == "HappyGift"
                    ||childrenArr[i].name=="FirstPay"
                    ||childrenArr[i].name=="PreferentialRecharge"
                    ||childrenArr[i].name=="GoldQuickPay"
                    ||childrenArr[i].name == "LowGoldQuickPay"
                    ||childrenArr[i].name=="MiddleGoldQuickPay"
                    ||childrenArr[i].name=="HighGoldQuickPay"
                    ||childrenArr[i].name=="LowDiamonQuickPay"
                    ||childrenArr[i].name == "MiddleDiamonQuickPay"
                    ||childrenArr[i].name=="HighDiamonQuickPay"
                    ||childrenArr[i].name=="NobleGift") {
                    // childrenArr[i].removeFromParent();
                    childrenArr[i].destroy();
                }
            }

        }
    };
    window.MessageBox = MessageBox;
})();


cc.Class({
    extends: cc.Component,

    properties: {
        okButton: {
            default: null,
            type: cc.Node
        },

        cancelButton: {
            default: null,
            type: cc.Node
        },

        oKImage: {
            default: null,
            type: cc.Sprite
        },
        cancelImage: {
            default: null,
            type: cc.Sprite
        },

        contentLabel: {
            default: null,
            type: cc.Label
        },

        ButtonTexts:{
            default:[],
            type:cc.SpriteFrame
        },
        LeftOKBtnNode:cc.Node,
        RightCancelBtnNode:cc.Node,
        CenterOKBtnNode:cc.Node,
        _style:-1,
        Style:{
            get(){
                return this._style;
            },
            set(value)
            {
                this._style = value;
                if(value == MessageBox.StyleEnum.OKCancel)
                {
                    this.okButton.position = this.LeftOKBtnNode.position;
                    this.okButton.active = true;
                    this.cancelButton.position = this.RightCancelBtnNode.position;
                    this.cancelButton.active = true;
                }else if(value == MessageBox.StyleEnum.OK)
                {
                    this.okButton.position = this.CenterOKBtnNode.position;
                    this.okButton.active = true;
                    this.cancelButton.active = false;
                }else if(value == MessageBox.StyleEnum.DeleteOrGet)
                {
                    this.okButton.position = this.LeftOKBtnNode.position;
                    this.okButton.active = true;
                    this.cancelButton.position = this.RightCancelBtnNode.position;
                    this.cancelButton.active = true;
                }
                else if(value == MessageBox.StyleEnum.ReconnectOrReturn)
                {
                    this.oKImage.spriteFrame = this.ButtonTexts[MessageBox.ButtonStyle.RECONNECT];
                    this.cancelImage.spriteFrame = this.ButtonTexts[MessageBox.ButtonStyle.BACKLOGIN];
                }
                else if(value == MessageBox.StyleEnum.Update)
                {
                    this.okButton.position = this.CenterOKBtnNode.position;
                    this.okButton.active = true;
                    this.cancelButton.active = false;
                    this.oKImage.spriteFrame = this.ButtonTexts[MessageBox.ButtonStyle.GOUP];
                }
                else if(value == MessageBox.StyleEnum.UpdateOrGoOnGame)
                {
                    this.okButton.position = this.LeftOKBtnNode.position;
                    this.okButton.active = true;
                    this.cancelButton.position = this.RightCancelBtnNode.position;
                    this.cancelButton.active = true;
                    this.oKImage.spriteFrame = this.ButtonTexts[MessageBox.ButtonStyle.GOUP];
                    this.cancelImage.spriteFrame = this.ButtonTexts[MessageBox.ButtonStyle.CONTINUE];
                }
                else if(value == MessageBox.StyleEnum.CancelOrImmediatelyPay)
                {
                    this.okButton.position = this.LeftOKBtnNode.position;
                    this.okButton.active = true;
                    this.cancelButton.position = this.RightCancelBtnNode.position;
                    this.cancelButton.active = true;
                    this.oKImage.spriteFrame = this.ButtonTexts[MessageBox.ButtonStyle.GOSHOP];
                    this.cancelImage.spriteFrame = this.ButtonTexts[MessageBox.ButtonStyle.CANCLE];
                }
                else if(value == MessageBox.StyleEnum.AddictionOrCancel)
                {
                    this.okButton.position = this.LeftOKBtnNode.position;
                    this.okButton.active = true;
                    this.cancelButton.position = this.RightCancelBtnNode.position;
                    this.cancelButton.active = true;
                    this.oKImage.spriteFrame = this.ButtonTexts[MessageBox.ButtonStyle.GOCHECK];
                    this.cancelImage.spriteFrame = this.ButtonTexts[MessageBox.ButtonStyle.DELAYGO];
                }
            }
        },
        __callBack: null,
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad() {
        //this.callBack = null;
    },


    show: function (content, type, callBack) {
        let self = this;
        this.Style = type;
        // switch (type) {
        //     case MessageBox.OKCancel:
        //         this.oKImage.string = "残忍退出";
        //         this.cancelImage.string = "继续游戏";
        //         break;
        //     case MessageBox.OK:
        //         this.oKImage.string = "确 定";
        //         this.okButton.x = 0;
        //         this.cancelButton.active = false;
        //         break;
        //     case MessageBox.DeleteOrGet:
        //         this.oKImage.string = "确 定";
        //         this.cancelImage.string = "取 消";
        //         break;
        //     case MessageBox.RETURN_RECONNECT:
        //         this.oKImage.string = "重新连接";
        //         this.cancelImage.string = "返回登录";
        //         break;
        //     case MessageBox.Update:
        //         this.oKImage.string = "前往更新";
        //         this.okButton.x = 0;
        //         this.cancelButton.active = false;
        //         break;
        //     case MessageBox.UpdateOrGoOnGame:
        //         this.oKImage.string = "前往更新";
        //         this.cancelImage.string = "继续游戏";
        //     default:
        //         break;
        // }
        this.__callBack = callBack;
        self.contentLabel.string = content;
        this.node.getComponent('ModalUI').IsShowCrazyLoading = false;
    },

    onOKButtonClicked: function () {
        if (this.__callBack) {
            this.__callBack(true);
        }
        this.node.destroy();
    },

    onCancelButtonClicked: function () {
        if (this.__callBack) {
            this.__callBack(false);
        }
        this.node.destroy();
    }
    // update (dt) {},
});
