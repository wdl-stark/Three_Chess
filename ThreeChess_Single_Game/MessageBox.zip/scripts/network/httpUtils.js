

var httpUtils = cc.Class({
    extends: cc.Component,
 
    properties: {
        // foo: {
        //    default: null,      // The default value will be used only when the component attaching
        //                           to a node for the first time
        //    url: cc.Texture2D,  // optional, default is typeof default
        //    serializable: true, // optional, default is true
        //    visible: true,      // optional, default is true
        //    displayName: 'Foo', // optional
        //    readonly: false,    // optional, default is false
        // },
        // ...
    },
 
    statics: {
        instance: null
    },
 
    // use this for initialization
    onLoad: function () {
    },
 
    httpGets: function (url, callback) {
        var xhr = cc.loader.getXMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && (xhr.status >= 200 && xhr.status < 300)) {
                var respone = xhr.responseText;
                callback(respone);
            }
            // else {
            //     callback(-1);
            // }
        };
        xhr.open("GET", url, true);
        // xhr.setRequestHeader("Origin", "http://cdngate.cggame.cc");
        // xhr.setRequestHeader("Accept-Encoding", "gzip,deflate");
        // note: In Internet Explorer, the timeout property may be set only after calling the open()
        // method and before calling the send() method.
        xhr.timeout = 5000;// 5 seconds for timeout
 
        xhr.send();
    },
 
    httpPost: function (url, params, callback) {
        var xhr = cc.loader.getXMLHttpRequest();
        xhr.onreadystatechange = function () {
            cc.log('xhr.readyState=' + xhr.readyState + '  xhr.status=' + xhr.status);
            var responeLog = xhr.responseText;
            console.log("responeLog: ", responeLog);
            if (xhr.readyState === 4 && (xhr.status >= 200 && xhr.status < 300)) {
                var respone = xhr.responseText;
                callback(respone);
            } else {
                callback(-1);
            }
        };
        xhr.open("POST", url, true);
        // xhr.setRequestHeader("Accept-Encoding", "gzip,deflate");
        // xhr.setRequestHeader("Origin", "http://cdngate.cggame.cc");
        xhr.setRequestHeader("content-type", "application/json");
        xhr.setRequestHeader("x-device_id",  GLOBAL.getSimId(false,16));
        // note: In Internet Explorer, the timeout property may be set only after calling the open()
        // method and before calling the send() method.
        xhr.timeout = 5000;// 5 seconds for timeout
        var sendstr=JSON.stringify(params);
        // xhr.withCredentials = true;
        console.log("sendstr", sendstr);
        xhr.send(sendstr);
    },

    HttpPost_EX(url, params, callback) {
        var xhr = cc.loader.getXMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4 && (xhr.status >= 200 && xhr.status < 300)) {
                var respone = xhr.responseText;
                callback(respone);
            } else {
                callback(-1);
            }
        };
        xhr.open("POST", url, true);
        xhr.setRequestHeader("content-type", "application/json");
        xhr.setRequestHeader("x-device_id", GLOBAL.getSimId(false,16));
        xhr.setRequestHeader("x-token", GLOBAL.loginInfo.token);
        xhr.setRequestHeader("x-user_id", GLOBAL.UID.toString());
        xhr.timeout = 5000;// 5 seconds for timeout
        var sendstr = JSON.stringify(params);
        xhr.send(sendstr);
    }
});
 
httpUtils.getInstance = function () {
    if (httpUtils.instance == null) {
        httpUtils.instance = new httpUtils();
    }
    return httpUtils.instance;
};
 
 
 

