
cc.Class({
    extends: cc.Component,

    properties: {
        messageText: cc.Label,
        _waitText: "",
        _leftTime: 0,
        _isOver: false
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},
    setMsg: function(message, isUpdate, leftTime) {
        this.messageText.string = message.format(leftTime);
        if(isUpdate) {
            this._waitText = message;
            this._leftTime = leftTime;
            this._isOver = false;
        } else {
            this._isOver = true;
            var delay = cc.delayTime(2);
            var self = this;
            var callFunc = cc.callFunc(function() {
                self.node.destroy();  
            });
            var actFadeIn = cc.fadeIn(0.5);
            self.node.runAction(cc.sequence(actFadeIn, delay, callFunc));
        }
    },

    update (dt) {
        this._leftTime -= dt;
        var leftTime = Math.floor(this._leftTime); 
        if(this._leftTime >= 0) {
            this.messageText.string = this._waitText.format(leftTime);
        } else {
            if(this._isOver == false) {
                this.messageText.string = "";
                this.node.destroy();
                this._isOver = true;
            }
        }
    },
});
