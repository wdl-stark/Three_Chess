const httpUtils = require('httpUtils');
cc.Class({
    extends: cc.Component,

    properties: {
        RuleText: cc.RichText,
    },
    Show()
    {
        httpUtils.getInstance().httpGets(GameConfig.BullFightRuleURL, (json) => {
            this.RuleText.string = json;
        });
        this.node.getComponent('ModalUI').IsShowCrazyLoading = false;
    },

    OnCloseButtonClick()
    {
        this.node.destroy();
    }
   
});
