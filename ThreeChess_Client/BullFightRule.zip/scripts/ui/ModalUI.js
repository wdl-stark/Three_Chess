var Utility = require('Utility');
cc.Class({
    extends: cc.Component,

    properties: {
        mask:{
            default:null,
            type:cc.Node,
        },

        content:{
            default: null,
            type:cc.Node,
        },

        animationDuration : 0.3,
        initScale : 0.8,
        fadeOutOpicity: {
            default: 204,
            tooltip: "最终遮罩层的透明度"
        },
        outScale:1,
        _isOnce: true,

        _IsShowCrazyLoading: null,
        IsShowCrazyLoading: {
            get() {
                return this._IsShowCrazyLoading;
            },
            set(value) {
                this._IsShowCrazyLoading = value;
                if (value){
                    this.node.width = 0;
                    this.node.height = 0;
                    this._isOnce = true;
                    // Utility.addCrazyLoading("",this.node);
                    // prefabFactory.instantiatePrefab(prefabFactory.CrazyLoading, cc.find("Canvas"), null);
                    // let creazyLoading = cc.instantiate(this.creazyLoading);
                    // creazyLoading.parent = cc.find("Canvas");
                } else {
                    // if (cc.find("Canvas").getChildByName('CrazyLoading')){
                    //     cc.find("Canvas").getChildByName('CrazyLoading').destroy();
                    // }
                    // cc.find("Canvas/Task/CrazyLoading").active = false;
                    // //console.log('this.node.children',this.node.children,this.node.getChildByName('CrazyLoading'));
                    Loading.Hidden();
                    this.node.width = 2000;
                    this.node.height = 2000;
                    if(this._isOnce){
                        this.showAni();
                        this._isOnce = false;
                    }

                }
            },
        },
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {

    },
    showAni(){
        let self = this;
        this.mask.on('touchstart', function (event) {
            event.stopPropagation();
        });
        this.mask.on('touchend', function (event) {
            event.stopPropagation();
        });

        this.content.scale = this.initScale;
        let fadeInAction = cc.fadeTo(this.animationDuration, 204);
        this.mask.runAction(fadeInAction);
        let jumpOutAction = cc.scaleTo(this.animationDuration, this.outScale);
        jumpOutAction.easing(cc.easeBackOut(3));

        // let animationCompleted = cc.callFunc(function(){
        //     self.node.emit("onFadeAnimationCompleted");
        // }, this);
        // let action = cc.sequence(jumpOutAction, animationCompleted);
        this.content.runAction(jumpOutAction);
    },

    close(){
        this.node.destroy();
    }

    // update (dt) {},
});
